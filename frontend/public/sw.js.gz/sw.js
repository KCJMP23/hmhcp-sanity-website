// HM Healthcare Partners - Service Worker
// Production-ready PWA service worker

const CACHE_NAME = 'hmhcp-v1.0.0'
const STATIC_CACHE = 'hmhcp-static-v1.0.0'
const DYNAMIC_CACHE = 'hmhcp-dynamic-v1.0.0'

// Resources to cache immediately
const STATIC_ASSETS = [
  '/',
  '/about',
  '/services',
  '/research',
  '/contact',
  '/offline',
  '/manifest.json',
  '/icon.svg',
  '/favicon.ico'
]

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('[SW] Install event')
  
  event.waitUntil(
    (async () => {
      try {
        const staticCache = await caches.open(STATIC_CACHE)
        await staticCache.addAll(STATIC_ASSETS)
        console.log('[SW] Static assets cached')
        await self.skipWaiting()
      } catch (error) {
        console.error('[SW] Install failed:', error)
      }
    })()
  )
})

// Activate event - clean old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activate event')
  
  event.waitUntil(
    (async () => {
      try {
        const cacheNames = await caches.keys()
        const validCacheNames = [STATIC_CACHE, DYNAMIC_CACHE]
        
        await Promise.all(
          cacheNames.map(cacheName => {
            if (!validCacheNames.includes(cacheName)) {
              console.log('[SW] Deleting old cache:', cacheName)
              return caches.delete(cacheName)
            }
          })
        )
        
        await self.clients.claim()
        console.log('[SW] Activated successfully')
      } catch (error) {
        console.error('[SW] Activation failed:', error)
      }
    })()
  )
})

// Admin routes and paths that should bypass service worker
const ADMIN_ROUTES = [
  '/admin',
  '/studio',
  '/api/admin',
  '/api/auth'
]

// Fetch event - handle requests
self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)
  
  // Skip service worker for non-GET requests
  if (request.method !== 'GET') return
  
  // Skip service worker for non-HTTP protocols
  if (!url.protocol.startsWith('http')) return
  
  // Skip service worker for admin routes
  if (shouldBypassServiceWorker(url.pathname)) {
    return
  }
  
  event.respondWith(handleRequest(request))
})

async function handleRequest(request) {
  const url = new URL(request.url)
  
  try {
    if (isStaticAsset(url.pathname)) {
      return handleStaticAsset(request)
    }
    
    return handlePage(request)
    
  } catch (error) {
    console.error('[SW] Request handling failed:', error)
    return handleOffline(request)
  }
}

async function handleStaticAsset(request) {
  const cache = await caches.open(STATIC_CACHE)
  
  try {
    const cachedResponse = await cache.match(request)
    if (cachedResponse) {
      return cachedResponse
    }
    
    const response = await fetch(request)
    if (response.ok) {
      await cache.put(request, response.clone())
    }
    
    return response
  } catch (error) {
    const cachedResponse = await cache.match(request)
    if (cachedResponse) {
      return cachedResponse
    }
    throw error
  }
}

async function handlePage(request) {
  const cache = await caches.open(DYNAMIC_CACHE)
  
  try {
    const cachedResponse = await cache.match(request)
    
    const fetchPromise = fetch(request).then(response => {
      if (response.ok) {
        cache.put(request, response.clone())
      }
      return response
    })
    
    if (cachedResponse) {
      fetchPromise.catch(() => {})
      return cachedResponse
    }
    
    return await fetchPromise
  } catch (error) {
    const cachedResponse = await cache.match(request)
    if (cachedResponse) {
      return cachedResponse
    }
    
    if (request.mode === 'navigate') {
      return handleOffline(request)
    }
    
    throw error
  }
}

async function handleOffline(request) {
  if (request.mode === 'navigate') {
    const cache = await caches.open(STATIC_CACHE)
    const offlinePage = await cache.match('/offline')
    
    if (offlinePage) {
      return offlinePage
    }
    
    return new Response(
      `<!DOCTYPE html>
      <html>
      <head>
        <title>Offline - HM Healthcare Partners</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body { font-family: system-ui, sans-serif; text-align: center; padding: 50px; }
          h1 { color: #1e40af; }
        </style>
      </head>
      <body>
        <h1>You're Offline</h1>
        <p>Please check your connection and try again.</p>
        <button onclick="location.reload()">Try Again</button>
      </body>
      </html>`,
      { headers: { 'Content-Type': 'text/html' }, status: 200 }
    )
  }
  
  return new Response('Network Error', { status: 408 })
}

function isStaticAsset(pathname) {
  return /\.(js|css|woff|woff2|ttf|eot|png|jpg|jpeg|gif|svg|webp|ico)$/.test(pathname) ||
         pathname.startsWith('/_next/static/')
}

// Check if a pathname should bypass the service worker
function shouldBypassServiceWorker(pathname) {
  return ADMIN_ROUTES.some(route => pathname.startsWith(route)) ||
         pathname.includes('/api/') && !pathname.startsWith('/api/public')
}

// Handle service worker updates
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting()
  }
})